import unittest
import pydoc
from programme import Calculator

class TestCalculator(unittest.TestCase):
    """
    A test case for the Calculator class.

    This test case checks the functionality of the Calculator class.
    """

    def test_add(self):
        """
        Test the addition method of the Calculator class.

        This test checks if the addition method correctly adds two numbers.
        """
        calculator = Calculator()
        result = calculator.addition(5, 3)
        self.assertEqual(result, 8, "Addition failed")

    def test_sub(self):
        """
        Test the subtraction method of the Calculator class.

        This test checks if the subtraction method correctly subtracts two numbers.
        """
        calculator = Calculator()
        result = calculator.subtraction(10, 4)
        self.assertEqual(result, 6, "Subtraction failed")

# Run the tests
unittest.main(argv=[''], verbosity=2, exit=False)

pydoc.writedoc(TestCalculator)