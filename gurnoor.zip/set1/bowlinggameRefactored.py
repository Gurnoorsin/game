import pydoc
class BowlingGame:
    """
    A class to represent a game of bowling.

    Attributes:
        rolls (list): A list to store the number of pins knocked down in each roll.
    """

    def __init__(self):
        """Initialize the BowlingGame with an empty list of rolls."""
        self.rolls = []

    def roll(self, pins):
        """
        Record the number of pins knocked down in a roll.

        Args:
            pins (int): The number of pins knocked down in the roll.
        """
        self.rolls.append(pins)

    def score(self):
        """
        Calculate the total score of the game.

        Returns:
            int: The total score of the game.
        """
        total_score = 0
        roll_index = 0

        for _ in range(10):  # 10 frames in a game
            if self.is_strike(roll_index):
                total_score += self.strike_score(roll_index)
                roll_index += 1
            elif self.is_spare(roll_index):
                total_score += self.spare_score(roll_index)
                roll_index += 2
            else:
                total_score += self.frame_score(roll_index)
                roll_index += 2

        return total_score

    def is_strike(self, roll_index):
        """
        Check if a roll is a strike.

        Args:
            roll_index (int): The index of the roll to check.

        Returns:
            bool: True if the roll is a strike, False otherwise.
        """
        return self.rolls[roll_index] == 10

    def is_spare(self, roll_index):
        """
        Check if two consecutive rolls form a spare.

        Args:
            roll_index (int): The index of the first roll to check.

        Returns:
            bool: True if the rolls form a spare, False otherwise.
        """
        return self.rolls[roll_index] + self.rolls[roll_index + 1] == 10

    def strike_score(self, roll_index):
        """
        Calculate the score for a strike.

        Args:
            roll_index (int): The index of the roll representing the strike.

        Returns:
            int: The score for the strike frame.
        """
        return 10 + self.rolls[roll_index + 1] + self.rolls[roll_index + 2]

    def spare_score(self, roll_index):
        """
        Calculate the score for a spare.

        Args:
            roll_index (int): The index of the first roll representing the spare.

        Returns:
            int: The score for the spare frame.
        """
        return 10 + self.rolls[roll_index + 2]

    def frame_score(self, roll_index):
        """
        Calculate the score for a regular frame (neither strike nor spare).

        Args:
            roll_index (int): The index of the first roll representing the frame.

        Returns:
            int: The score for the frame.
        """
        return self.rolls[roll_index] + self.rolls[roll_index + 1]

pydoc.writedoc(BowlingGame)

# Test Plan with Test Cases

import unittest

class TestBowlingGame(unittest.TestCase):
    def setUp(self):
        self.game = BowlingGame()

    def roll_many(self, pins, rolls):
        for _ in range(rolls):
            self.game.roll(pins)

    def test_all_rolls_zero(self):
        self.roll_many(0, 20)
        self.assertEqual(self.game.score(), 0)

    def test_all_rolls_one(self):
        self.roll_many(1, 20)
        self.assertEqual(self.game.score(), 20)

    def test_all_rolls_strike(self):
        self.game.roll(10)  # Strike
        self.roll_many(0, 18)
        self.assertEqual(self.game.score(), 10)

    def test_all_rolls_spare(self):
        self.game.roll(5)
        self.game.roll(5)  # Spare
        self.roll_many(1, 18)
        self.assertEqual(self.game.score(), 29)

    def test_perfect_game(self):
        self.roll_many(10, 12)
        self.assertEqual(self.game.score(), 300)

if __name__ == '__main__':
    unittest.main()

pydoc.writedoc(TestBowlingGame)
